# Luke Francke Theme


![Luke Francke](screenshot.png)

## Description
The **Luke Francke** Theme is a private Theme for [Grav CMS](http://github.com/getgrav/grav).  

This Theme is a modified version of the Chalk Theme, provided by Paul Massendari [that can be found here](https://github.com/paulmassen/grav-theme-chalk).
