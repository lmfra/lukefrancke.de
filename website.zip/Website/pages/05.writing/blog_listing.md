---
title: Writing
published: true
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 15
    pagination: true
---

<h1 class="page-title">Writing</h1>
