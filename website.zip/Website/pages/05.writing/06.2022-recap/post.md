---
title: '2022 recap'
published: true
date: '24-12-2022 15:04'
headline: 'What happened in 2022'
media_order: 'candle.jpg,amsterdam.jpg,window.jpg,croatia-waves.jpg,2FD2D299-5570-4D62-8C93-9DAD99254D45.jpeg,787AA73B-3A48-43B1-8C00-CC7FCC076772.jpeg,A93B14B0-B44A-4C12-A37D-894E71CCB759.jpeg,DD2F5F0A-C989-420B-8696-85048D5E8C16.jpeg'
taxonomy:
    tag:
        - '2022'
---

Christmas time and the upcoming end of the year is the most beautiful time for me. So pre-Christmas time has been again this year a moment full of shine, joy and beautiful moments. On this way I'd like to thank my family and friends, as well as all the people who have enriched my life and those I met.

<img class="image" src="/writing/2022-recap/candle.jpg">

I was able to visit wonderful places and enjoy many moments, for which I am very grateful.

<img class="image" src="/writing/2022-recap/amsterdam.jpg">

During the summer vacation I visited Amsterdam. The city is very beautiful and impressive. There was also a lot to discover there and I was able to take many beautiful photos.

<img class="image" src="/writing/2022-recap/croatia-waves.jpg">

Moreover, I was in Croatia, where I could spend a nice time. Also there some beautiful photos were taken.

I hope that next year will be even better and I am excited to see what will happen.

<p class="grey">Have a great holiday season and a good start into 2023!</p>

<h3 class="grey">Some great moments:</h3>
<img class="image" src="/writing/2022-recap/window.jpg">
<img class="image" src="/writing/2022-recap/DD2F5F0A-C989-420B-8696-85048D5E8C16.jpeg">
<img class="image" src="/writing/2022-recap/A93B14B0-B44A-4C12-A37D-894E71CCB759.jpeg">
<img class="image" src="/writing/2022-recap/787AA73B-3A48-43B1-8C00-CC7FCC076772.jpeg">
<img class="image" src="/writing/2022-recap/2FD2D299-5570-4D62-8C93-9DAD99254D45.jpeg">