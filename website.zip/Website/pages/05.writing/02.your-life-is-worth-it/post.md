---
title: 'Your life is worth it.'
media_order: 6AFB4D17-7F08-4C95-A634-3C4F94A481F0.jpeg
date: '22-08-2022 22:19'
taxonomy:
    tag:
        - life
---

Lately, I keep seeing people not enjoying their lives to the fullest. You let yourself be influenced by small things that keep you busy for weeks and thus make life more difficult. I also had some situations where this was the case.

That's why I want to share some advice now:

### 1. focus on yourself.
Focus on your goals, things you like to do and people you love.

### 2. find new things that you like.
Go outside, explore the world, find places or things you like.

### 3. don't listen to other people.
Some people don't want you to have your dreams or successes? Keep going. It's best to do your thing, no matter what others say.

### 4. most important:
<img class="image"  src="/writing/your-life-is-worth-it/6AFB4D17-7F08-4C95-A634-3C4F94A481F0.jpeg">
