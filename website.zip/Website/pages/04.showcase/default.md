---
title: Photography
media_order: '1F4FE49E-7793-4467-9A22-A8CE1204C24E.jpeg,5B8E5C08-CB66-4CBF-B610-A2E46C76898C.jpeg,8F7047EB-7021-49B1-A3C6-3129894D4C89.jpeg,10E59F1F-3996-44F5-9806-04AFDC996C97.jpeg,12D5373E-F354-4E0B-B4A4-8863ADA66EF9.jpeg,32F6F38C-02FC-45B5-BAA1-22272F513BF3.jpeg,48F33924-C11D-4BEE-8781-A022B34E0338.jpeg,240FA487-DFF9-47C1-BE79-AA320E7A8782.jpeg,2829D286-1B6B-42C2-AFC9-63D134E3689A.jpeg,5540B9C0-F51E-4525-A51C-F8B125DEC0B7.jpeg,34957AB9-E997-4329-AF2E-E1C9037E151D.jpeg,93639DF0-73A9-47C1-AEB1-2B83B5BCAAED.jpeg,A49E0E53-3D80-4D5E-8BD5-8623BE4DD9F8.jpeg,art.webp,B6E1F8E0-A969-44D9-A30A-0883F851FD7D.jpeg,beach-sunset.jpg,butterfly-flower.jpeg,C28AA775-617B-4669-AF7D-78A74263B8BC.jpeg,CEAE2CAE-8CD5-4EB2-897D-DE2AA4C753E7.jpeg,lily.jpeg,purple-flowers.jpeg,sand.webp,sunset-field.jpg,sunset-w.jpeg,water.jpeg,6DAB2F0B-90CB-4BFC-A69F-B209857BBD87.jpeg,0681A144-9B4F-4613-89A2-81B1BC4F11A4.jpeg,98F453FF-BA34-4D74-A242-D67313EAE3D2.jpeg,5689F4FB-89AB-4A37-B61C-0A1B2E05E4F9.jpeg,IMG_4008.jpeg,IMG_1729.jpeg,IMG_1008.jpeg'
---

<h1 class="page-title">Showcase: Photography</h1>
<p class="strong grey">Colors rising out of the darkness.</p>
<div class="divider"></div>
<div class="row">
<div class="column">
<img src="/showcase/IMG_1008.jpeg" />
<img src="/showcase/IMG_4008.jpeg" />
<img src="/showcase/5689F4FB-89AB-4A37-B61C-0A1B2E05E4F9.jpeg" />
<img src="/showcase/98F453FF-BA34-4D74-A242-D67313EAE3D2.jpeg" />
<img src="/showcase/5B8E5C08-CB66-4CBF-B610-A2E46C76898C.jpeg" />
<img src="/showcase/8F7047EB-7021-49B1-A3C6-3129894D4C89.jpeg" />
<img src="/showcase/10E59F1F-3996-44F5-9806-04AFDC996C97.jpeg" />
<img src="/showcase/12D5373E-F354-4E0B-B4A4-8863ADA66EF9.jpeg" />
<img src="/showcase/32F6F38C-02FC-45B5-BAA1-22272F513BF3.jpeg" />
<img src="/showcase/34957AB9-E997-4329-AF2E-E1C9037E151D.jpeg" />
<img src="/showcase/240FA487-DFF9-47C1-BE79-AA320E7A8782.jpeg" />
<img src="/showcase/2829D286-1B6B-42C2-AFC9-63D134E3689A.jpeg" />
</div>
<div class="column">
<img src="/showcase/IMG_1729.jpeg" />
<img src="/showcase/48F33924-C11D-4BEE-8781-A022B34E0338.jpeg" />
<img src="/showcase/0681A144-9B4F-4613-89A2-81B1BC4F11A4.jpeg" />
<img src="/showcase/93639DF0-73A9-47C1-AEB1-2B83B5BCAAED.jpeg" />
<img src="/showcase/A49E0E53-3D80-4D5E-8BD5-8623BE4DD9F8.jpeg" />
<img src="/showcase/B6E1F8E0-A969-44D9-A30A-0883F851FD7D.jpeg" />
<img src="/showcase/beach-sunset.jpg" />
<img src="/showcase/C28AA775-617B-4669-AF7D-78A74263B8BC.jpeg" />
<img src="/showcase/CEAE2CAE-8CD5-4EB2-897D-DE2AA4C753E7.jpeg" />
<img src="/showcase/sunset-w.jpeg" />
<img src="/showcase/5540B9C0-F51E-4525-A51C-F8B125DEC0B7.jpeg" />
<img src="/showcase/1F4FE49E-7793-4467-9A22-A8CE1204C24E.jpeg" />
</div>
</div>
<p class="red-note">All images on this page were created by me and may not be used without permission. This must be obtained in writing. You can find information to contact me <a href="/contact">here</a>.</p>
<div id="callout" class="callout">
<div class="callout-close-container">
<div class="callout-close" onclick="getElementById('callout').style.display='none';"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#232323" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></div>
</div>
<p>My photography showcase gets updated regularly.</p>
</div>
