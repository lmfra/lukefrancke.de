---
title: Docs
---

<h1 class="page-title">Docs</h1>
<h4>There is currently no specific content on this page. Please select one of the following subpages.</h4><a class="button center-button" href="/docs/legal">Legal notice</a>
<a class="button center-button" href="/docs/privacy">Privacy policy</a>
