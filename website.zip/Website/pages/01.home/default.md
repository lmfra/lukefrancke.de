---
title: Home
media_order: start-bg.webp
routes:
    aliases:
        - home
---

<p class="hero-text">I am Luke Francke;</br>a student, web designer & developer.<br /><a class="hero-link strong" href="/about">read more<svg class="nav-icon" xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#464646" stroke-width="2.75" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a></p>
<img class="hero-cover" src="/user/themes/luke/images/sea.webp" />
<p>I design and develop products that are easy to use and add value to the world.<br />When I'm not working in front of a computer, I like to spend time in nature, photograph the beauty of the planet and fight for privacy and data protection.</p>
<p class="strong">Let's create something special together.</p>
