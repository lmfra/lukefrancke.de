---
title: Now
published: true
---

<h1 class="page-title">/now</h1>
<p><span class="small grey">last updated: April 5, 2023</span></p>

<button class="collapsible">Free time</button>
<div class="collapsible-content">
<p>Spending some time with Lio, the Havanese Dog. <br />Developing new features for this site and some other projects. <br />Enjoying the beauty of spring.</p>
</div>
<button class="collapsible">School</button>
<div class="collapsible-content">
<p>Abitur exams coming soon. Writing study notes, guidelines, and reviewing content.</p>
</div><a class="button" href="/about">more about me</a>
<div class="space"></div>
<p class="now-text">If you want to learn more about /now pages, take a look here: <a href="https://nownownow.com/about">nownownow.com</a><span class="external-icon"></span> (you can create your own, too!)</p>
