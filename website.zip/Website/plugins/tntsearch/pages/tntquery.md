---
title: TNTSearch Query
template_format: json
cache_control: no-cache
---